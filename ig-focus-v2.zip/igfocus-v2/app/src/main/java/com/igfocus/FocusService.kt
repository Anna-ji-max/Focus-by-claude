package com.igfocus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * IG Focus — Accessibility Overlay Service
 *
 * Draws TYPE_ACCESSIBILITY_OVERLAY windows on top of Instagram.
 * No SYSTEM_ALERT_WINDOW permission needed — the accessibility service
 * type grants this automatically.
 *
 * Overlay map (what we cover and what we leave free):
 *
 *  ┌──────────────────────────────┐  ← status bar (system, untouched)
 *  │  Instagram header + create   │  ← FREE (user needs this)
 *  │  Stories row                 │  ← FREE (friends' stories work)
 *  ├──────────────────────────────┤  ← storyRowBottom  ──────────┐
 *  │  🔒  FEED BLOCKER            │                              │
 *  │      (home screen only)      │  blocks all feed             │
 *  │      shows motivational      │  touches + scroll            │
 *  │      quote                   │                              │
 *  ├──────────────────────────────┤  ← navBar.top  ─────────────┘
 *  │  🔲  NAV DIMMER (passthru)   │  ← dim layer, touches pass
 *  │  🏠  [srch] [🔒reels] [🔔] 👤 │    through to Home/Search/Profile
 *  │              └─ REELS BLOCK  │  ← opaque, blocks tap on Reels icon
 *  └──────────────────────────────┘
 *
 * Additional states:
 *  REELS  → full-screen opaque block over entire display
 *  SEARCH → block covers suggestions area, search bar still free
 *  OTHER  → only nav reels blocker stays (DMs, profile stay usable)
 */
class FocusService : AccessibilityService() {

    /* ── Screen state ── */
    private enum class Screen { HOME, REELS, SEARCH, OTHER }
    private var currentScreen = Screen.OTHER

    /* ── Overlay views ── */
    private var feedBlocker:    View? = null   // home feed area below stories
    private var reelsTabBlock:  View? = null   // Reels icon in bottom nav
    private var navDimmer:      View? = null   // dim over whole nav bar (touch passthrough)
    private var reelsFullBlock: View? = null   // entire screen when full-screen reels detected
    private var searchBlock:    View? = null   // search suggestions area

    /* ── Runtime ── */
    private var wm: WindowManager? = null
    private var igOpen = false
    private var retries = 0
    private val handler = Handler(Looper.getMainLooper())

    /* ── Motivational quotes ── */
    private val quotes = arrayOf(
        "Protect your attention.\nIt's your most valuable asset.",
        "Real life  >  Reel life.\nBe present.",
        "Create more than you consume.",
        "Every scroll is a choice.\nChoose wisely.",
        "Your focus determines\nyour reality.",
        "Deep work > shallow scrolling.",
        "The best moments\naren't on a screen.",
        "Discipline is the bridge\nbetween goals and achievement.",
        "What you do today\nshapes who you become.",
        "Guard your mind.\nFeed it with purpose."
    )

    /* ────────────────────────────────────────────
       THEME  — matches Instagram's exact palette
       Dark:  bg=#000000  text=#FFFFFF  sub=#8E8E8E
       Light: bg=#FAFAFA  text=#000000  sub=#737373
       ──────────────────────────────────────────── */

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                 Configuration.UI_MODE_NIGHT_YES

    // Semi-opaque block — looks like a native Instagram panel
    private val cBlock: Int   get() = if (isDark) Color.argb(242, 0, 0, 0)        else Color.argb(242, 250, 250, 250)
    // Lighter dim for nav bar (touch-through)
    private val cDim: Int     get() = if (isDark) Color.argb(200, 8, 8, 8)         else Color.argb(200, 245, 245, 245)
    // Primary text
    private val cText: Int    get() = if (isDark) Color.WHITE                       else Color.argb(255, 10, 10, 10)
    // Secondary / hint text  (Instagram's exact grey values)
    private val cSub: Int     get() = if (isDark) Color.argb(255, 142, 142, 142)   else Color.argb(255, 115, 115, 115)
    // Instagram blue accent (used for small divider lines etc.)
    private val cAccent: Int  get() = Color.argb(255, 0, 149, 246) // #0095F6

    /* ════════════════════════════════════════════
       LIFECYCLE
       ════════════════════════════════════════════ */

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Bump to Instagram-aware mode when service first connects
        // (handles the case where IG is already open when user enables the service)
        handler.postDelayed({
            rootInActiveWindow?.let { root ->
                if (root.packageName?.toString() == "com.instagram.android") {
                    igOpen = true
                    boostEventMode()
                    handler.postDelayed(::refresh, 800)
                }
                root.recycle()
            }
        }, 500)
    }

    override fun onInterrupt() = nukeAll()
    override fun onDestroy() { super.onDestroy(); nukeAll() }

    /* ════════════════════════════════════════════
       EVENT ROUTING
       ════════════════════════════════════════════ */

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return

        if (pkg == "com.instagram.android") {
            if (!igOpen) {
                igOpen = true
                retries = 0
                boostEventMode()       // switch to high-detail event listening
            }
            // Debounce: re-analyse 250 ms after the last event burst
            handler.removeCallbacksAndMessages(null)
            handler.postDelayed(::refresh, 250)
        } else {
            if (igOpen) {
                igOpen = false
                quietEventMode()       // switch back to lightweight listening
                handler.post(::nukeAll)
            }
        }
    }

    /** Lightweight mode: only window-state events from every app.
     *  Used when Instagram is in background — minimal battery impact. */
    private fun quietEventMode() {
        val i = serviceInfo ?: return
        i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        i.packageNames = null
        i.notificationTimeout = 200
        serviceInfo = i
    }

    /** Full mode: window-state + content-changed, Instagram only.
     *  Used when Instagram is in foreground — lets us track screen changes. */
    private fun boostEventMode() {
        val i = serviceInfo ?: return
        i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                       AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        i.packageNames = arrayOf("com.instagram.android")
        i.notificationTimeout = 150
        serviceInfo = i
    }

    /* ════════════════════════════════════════════
       REFRESH  —  runs on every debounced event
       ════════════════════════════════════════════ */

    private fun refresh() {
        if (!igOpen) return
        val root = rootInActiveWindow
        if (root == null) {
            if (retries++ < 14) handler.postDelayed(::refresh, 320)
            return
        }
        retries = 0

        val screen = detectScreen(root)
        applyOverlays(screen, root)   // root recycled inside
    }

    /* ════════════════════════════════════════════
       SCREEN DETECTION
       ════════════════════════════════════════════ */

    private fun detectScreen(root: AccessibilityNodeInfo): Screen {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels

        // 1. Full-screen reels: Instagram shows Like/Comment/Share action buttons
        //    in a RIGHT COLUMN at mid-height. This signature only appears in reels player.
        if (isFullScreenReels(root, sw, sh)) return Screen.REELS

        // 2. Search tab: wide search EditText at very top of screen
        if (isSearchTab(root, sw, sh)) return Screen.SEARCH

        // 3. Home tab: "Your story" circle is always present in the story row
        if (isHomeTab(root)) return Screen.HOME

        // 4. Everything else: DMs, profile, settings — no feed blocking needed
        return Screen.OTHER
    }

    /** Reels detection: right-column action buttons at mid-screen */
    private fun isFullScreenReels(root: AccessibilityNodeInfo, sw: Int, sh: Int): Boolean {
        // Instagram renders Like, Comment, Audio labels in the right ~35% of screen
        // when playing a reel in full-screen mode.
        for (term in listOf("Like", "Comment", "Audio", "Share this")) {
            val nodes = root.findAccessibilityNodeInfosByText(term)
            for (n in nodes) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                if (b.left > sw * 0.62f && b.top > sh * 0.22f && b.bottom < sh * 0.93f) return true
            }
        }
        return false
    }

    /** Search tab detection: a wide search bar at the very top */
    private fun isSearchTab(root: AccessibilityNodeInfo, sw: Int, sh: Int): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText("Search")
        for (n in nodes) {
            val b = Rect(); n.getBoundsInScreen(b); n.recycle()
            // Search bar spans >40% width and lives in the top 14% of screen
            if (b.top < sh * 0.14f && b.width() > sw * 0.40f) return true
        }
        return false
    }

    /** Home tab detection: "Your story" always visible in the story row */
    private fun isHomeTab(root: AccessibilityNodeInfo): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText("Your story")
        val found = nodes.isNotEmpty()
        nodes.forEach { it.recycle() }
        return found
    }

    /* ════════════════════════════════════════════
       OVERLAY APPLICATION
       ════════════════════════════════════════════ */

    private fun applyOverlays(screen: Screen, root: AccessibilityNodeInfo) {
        // ── Always present on any Instagram screen ──────────────────────────
        // Nav dimmer + Reels tab blocker persist across HOME/SEARCH/OTHER so
        // the user can never accidentally open Reels from any screen.
        val nav      = findNavBar(root)
        val reelsTab = findReelsTab(root)
        placeNavDimmer(nav)
        placeReelsTabBlock(reelsTab, nav)

        // ── Screen-specific overlays ────────────────────────────────────────
        when (screen) {

            Screen.HOME -> {
                // Clear overlays from other screens
                nuke(reelsFullBlock); reelsFullBlock = null
                nuke(searchBlock);    searchBlock    = null
                // Place the feed blocker below the story row
                placeFeedBlocker(root, nav)
            }

            Screen.REELS -> {
                // Full-screen cover — user somehow got into reels (swipe, link, etc.)
                nuke(feedBlocker);   feedBlocker  = null
                nuke(searchBlock);   searchBlock  = null
                // Only add if not already showing (avoids flicker)
                if (reelsFullBlock == null) {
                    val dm = resources.displayMetrics
                    reelsFullBlock = buildReelsFullView()
                    place(reelsFullBlock!!, Rect(0, 0, dm.widthPixels, dm.heightPixels),
                          FLAG_NOT_FOCUSABLE)
                }
            }

            Screen.SEARCH -> {
                nuke(feedBlocker);    feedBlocker   = null
                nuke(reelsFullBlock); reelsFullBlock = null
                // Cover suggestions area but leave search bar free
                placeSearchBlocker(root, nav)
            }

            Screen.OTHER -> {
                // DMs, profile, settings — clear content blockers
                // (nav reels block placed above stays active)
                nuke(feedBlocker);    feedBlocker   = null
                nuke(reelsFullBlock); reelsFullBlock = null
                nuke(searchBlock);    searchBlock   = null
            }
        }

        root.recycle()
        currentScreen = screen
    }

    /* ── Individual overlay placers ── */

    /** Dim layer over the full bottom nav bar — touch-passthrough so
     *  Home/Search/Profile icons remain tappable underneath. */
    private fun placeNavDimmer(nav: Rect?) {
        nuke(navDimmer); navDimmer = null
        val dm = resources.displayMetrics
        val b = nav ?: Rect(0, dm.heightPixels - dp(58), dm.widthPixels, dm.heightPixels)
        navDimmer = View(this).apply { setBackgroundColor(cDim) }
        place(navDimmer!!, b, FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE)
    }

    /** Opaque block over just the Reels tab icon — blocks taps, shows 🎯 */
    private fun placeReelsTabBlock(reelsTab: Rect?, nav: Rect?) {
        nuke(reelsTabBlock); reelsTabBlock = null
        val dm = resources.displayMetrics
        val b = reelsTab ?: run {
            val nh = nav?.height() ?: dp(58)
            val tw = dm.widthPixels / 5
            Rect(tw * 2, dm.heightPixels - nh, tw * 3, dm.heightPixels)
        }
        reelsTabBlock = buildReelsTabView()
        place(reelsTabBlock!!, b, FLAG_NOT_FOCUSABLE) // no NOT_TOUCHABLE → blocks tap
    }

    /** Feed blocker: from just below the story row to the top of the nav bar.
     *  This is the main content guard — prevents scrolling the home feed. */
    private fun placeFeedBlocker(root: AccessibilityNodeInfo, nav: Rect?) {
        nuke(feedBlocker); feedBlocker = null

        val dm     = resources.displayMetrics
        val storyB = findStoryRowBottom(root) ?: dp(265)   // fallback ≈ story row height
        val navTop = nav?.top ?: (dm.heightPixels - dp(58))

        if (navTop <= storyB + dp(20)) return  // no room → skip

        feedBlocker = buildFeedView()
        place(feedBlocker!!, Rect(0, storyB, dm.widthPixels, navTop), FLAG_NOT_FOCUSABLE)
    }

    /** Search suggestions blocker: from below the search bar to the nav bar.
     *  Blocks taps on suggestions. Keyboard input still reaches the search bar
     *  above the overlay because FLAG_NOT_FOCUSABLE keeps IME focus on the EditText. */
    private fun placeSearchBlocker(root: AccessibilityNodeInfo, nav: Rect?) {
        nuke(searchBlock); searchBlock = null

        val dm      = resources.displayMetrics
        val srchBot = findSearchBarBottom(root) ?: dp(112)
        val navTop  = nav?.top ?: (dm.heightPixels - dp(58))

        if (navTop <= srchBot + dp(10)) return

        searchBlock = buildSearchView()
        place(searchBlock!!, Rect(0, srchBot, dm.widthPixels, navTop), FLAG_NOT_FOCUSABLE)
    }

    /* ════════════════════════════════════════════
       ELEMENT FINDERS  (walk the accessibility tree)
       ════════════════════════════════════════════ */

    /** Bottom of the story row — where our feed blocker starts.
     *  "Your story" label sits at the bottom of its circle, so its .bottom
     *  is already the bottom edge of the story row. */
    private fun findStoryRowBottom(root: AccessibilityNodeInfo): Int? {
        for (term in listOf("Your story", "Add to story")) {
            val nodes = root.findAccessibilityNodeInfosByText(term)
            if (nodes.isNotEmpty()) {
                val b = Rect(); nodes[0].getBoundsInScreen(b)
                nodes.forEach { it.recycle() }
                return b.bottom + dp(4)
            }
        }
        return null
    }

    /** Recursively find the bottom navigation bar: a wide, short container
     *  at the very bottom of the screen. */
    private fun findNavBar(root: AccessibilityNodeInfo): Rect? {
        val dm = resources.displayMetrics
        return navSearch(root, dm.widthPixels, dm.heightPixels, dp(42), dp(78))
    }

    private fun navSearch(n: AccessibilityNodeInfo, sw: Int, sh: Int, mn: Int, mx: Int): Rect? {
        val b = Rect().also { n.getBoundsInScreen(it) }
        // Nav bar signature: wide (>78% screen), short (42–78 dp), touching the bottom
        if (b.width() > sw * 0.78 && b.height() in mn..mx && b.bottom >= sh - dp(16)) return b
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val f = navSearch(c, sw, sh, mn, mx); c.recycle()
            if (f != null) return f
        }
        return null
    }

    /** Find the Reels tab icon by its content description ("Reels") in the
     *  bottom 25% of the screen. */
    private fun findReelsTab(root: AccessibilityNodeInfo): Rect? {
        val sh = resources.displayMetrics.heightPixels
        for (term in listOf("Reels", "Reels tab")) {
            val nodes = root.findAccessibilityNodeInfosByText(term)
            for (n in nodes) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                // Must be in the bottom nav zone and narrow (icon, not post)
                if (!b.isEmpty && b.top >= sh * 0.75f && b.width() < dp(90)) return b
            }
        }
        return null
    }

    /** Bottom edge of the search bar so we know where suggestions start. */
    private fun findSearchBarBottom(root: AccessibilityNodeInfo): Int? {
        val sw = resources.displayMetrics.widthPixels
        val nodes = root.findAccessibilityNodeInfosByText("Search")
        for (n in nodes) {
            val b = Rect(); n.getBoundsInScreen(b); n.recycle()
            if (b.width() > sw * 0.35f) return b.bottom + dp(4)
        }
        return null
    }

    /* ════════════════════════════════════════════
       VIEW BUILDERS  — Instagram-themed overlays
       ════════════════════════════════════════════ */

    /** Small opaque tile over the Reels tab icon */
    private fun buildReelsTabView(): View {
        val frame = FrameLayout(this).apply { setBackgroundColor(cBlock) }
        frame.addView(
            TextView(this).apply {
                text = "🎯"
                textSize = 18f
                gravity = Gravity.CENTER
            },
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ).apply { gravity = Gravity.CENTER }
        )
        return frame
    }

    /** Large feed blocker — fills the entire feed area below stories */
    private fun buildFeedView(): LinearLayout {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBlock)
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }

        // Thin top accent line — matches Instagram's story ring gradient
        val accent = View(this).apply {
            setBackgroundColor(cAccent)
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(2)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(18)
            }
        }
        ll.addView(accent)

        ll.addView(mkTv("🔒", 34f, cText, Gravity.CENTER))
        ll.addView(mkTv("Feed hidden", 17f, cText, Gravity.CENTER, bold = true).apply {
            setPadding(0, dp(12), 0, dp(6))
        })
        ll.addView(mkTv(quotes.random(), 13f, cSub, Gravity.CENTER).apply {
            setPadding(0, dp(4), 0, dp(22))
            setLineSpacing(dp(3).toFloat(), 1f)
        })

        // Separator
        ll.addView(View(this).apply {
            setBackgroundColor(if (isDark) Color.argb(40, 255, 255, 255)
                               else Color.argb(40, 0, 0, 0))
            layoutParams = LinearLayout.LayoutParams(dp(80), 1).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(18)
            }
        })

        ll.addView(mkTv("Stories from friends are\nstill available above  ↑",
            11f, cSub, Gravity.CENTER).apply { alpha = 0.55f })

        return ll
    }

    /** Full-screen block when user somehow reaches the Reels player */
    private fun buildReelsFullView(): LinearLayout {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBlock)
            setPadding(dp(36), dp(36), dp(36), dp(36))
        }
        ll.addView(mkTv("🚫", 52f, cText, Gravity.CENTER))
        ll.addView(mkTv("Reels blocked", 22f, cText, Gravity.CENTER, bold = true).apply {
            setPadding(0, dp(18), 0, dp(10))
        })
        ll.addView(mkTv(quotes.random(), 14f, cSub, Gravity.CENTER).apply {
            setPadding(dp(20), dp(4), dp(20), dp(36))
            setLineSpacing(dp(4).toFloat(), 1f)
        })
        ll.addView(mkTv("Use ← back gesture or tap 🏠 to return",
            12f, cSub, Gravity.CENTER).apply { alpha = 0.6f })
        return ll
    }

    /** Covers search suggestions but leaves the search EditText free */
    private fun buildSearchView(): LinearLayout {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBlock)
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        ll.addView(mkTv("🔍", 30f, cText, Gravity.CENTER))
        ll.addView(mkTv("Suggestions hidden", 15f, cText, Gravity.CENTER, bold = true).apply {
            setPadding(0, dp(12), 0, dp(6))
        })
        ll.addView(mkTv("Type in the search bar above\nto find friends and accounts",
            12f, cSub, Gravity.CENTER).apply {
            setLineSpacing(dp(3).toFloat(), 1f); alpha = 0.7f
        })
        return ll
    }

    /* ════════════════════════════════════════════
       WINDOWMANAGER HELPERS
       ════════════════════════════════════════════ */

    private fun place(v: View, b: Rect, flags: Int) {
        val p = LayoutParams(
            b.width(), b.height(), b.left, b.top,
            TYPE_ACCESSIBILITY_OVERLAY,     // works without SYSTEM_ALERT_WINDOW
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try { wm?.addView(v, p) } catch (e: Exception) { /* view already attached */ }
    }

    private fun nuke(v: View?) {
        v ?: return
        try { wm?.removeView(v) } catch (e: Exception) { /* already detached */ }
    }

    private fun nukeAll() {
        listOf(feedBlocker, reelsTabBlock, navDimmer, reelsFullBlock, searchBlock)
            .forEach { nuke(it) }
        feedBlocker = null; reelsTabBlock = null; navDimmer = null
        reelsFullBlock = null; searchBlock = null
        currentScreen = Screen.OTHER
    }

    /* ════════════════════════════════════════════
       SMALL UTILS
       ════════════════════════════════════════════ */

    private fun mkTv(
        text: String, size: Float, col: Int, grav: Int, bold: Boolean = false
    ) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(col)
        gravity = grav
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
}
